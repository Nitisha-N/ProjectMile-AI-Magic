import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, accuracy_score
import joblib
import json
from datetime import datetime, timedelta

class DeadlinePredictionModel:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
    
    def prepare_features(self, task_data):
        """Extract features for deadline prediction"""
        features = {
            'estimated_hours': task_data.get('estimated_hours', 8),
            'complexity_score': task_data.get('complexity_score', 5),
            'num_dependencies': len(json.loads(task_data.get('dependencies', '[]'))),
            'project_priority': task_data.get('project_priority', 1),
            'assigned_experience': task_data.get('assigned_experience', 3),  # 1-5 scale
            'current_workload': task_data.get('current_workload', 5)  # hours per day
        }
        return np.array(list(features.values())).reshape(1, -1)
    
    def train(self, training_data):
        """Train the deadline prediction model"""
        df = pd.DataFrame(training_data)
        
        X = df[['estimated_hours', 'complexity_score', 'num_dependencies', 
                'project_priority', 'assigned_experience', 'current_workload']]
        y = df['actual_completion_days']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        self.model.fit(X_train_scaled, y_train)
        self.is_trained = True
        
        # Evaluate
        predictions = self.model.predict(X_test_scaled)
        mae = mean_absolute_error(y_test, predictions)
        print(f"Deadline Prediction MAE: {mae:.2f} days")
        
        return mae
    
    def predict_completion_time(self, task_features):
        """Predict task completion time in days"""
        if not self.is_trained:
            return None
        
        features_scaled = self.scaler.transform(task_features)
        prediction = self.model.predict(features_scaled)[0]
        return max(0.1, prediction)  # Minimum 0.1 days
    
    def save_model(self, path):
        """Save trained model"""
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'is_trained': self.is_trained
        }, path)
    
    def load_model(self, path):
        """Load trained model"""
        data = joblib.load(path)
        self.model = data['model']
        self.scaler = data['scaler']
        self.is_trained = data['is_trained']

class TaskPriorityModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
    
    def prepare_features(self, task_data):
        """Extract features for priority classification"""
        features = {
            'deadline_urgency': task_data.get('days_until_deadline', 30),
            'project_priority': task_data.get('project_priority', 1),
            'complexity_score': task_data.get('complexity_score', 5),
            'stakeholder_impact': task_data.get('stakeholder_impact', 3),  # 1-5 scale
            'business_value': task_data.get('business_value', 3),  # 1-5 scale
            'num_dependencies': len(json.loads(task_data.get('dependencies', '[]')))
        }
        return np.array(list(features.values())).reshape(1, -1)
    
    def train(self, training_data):
        """Train the priority classification model"""
        df = pd.DataFrame(training_data)
        
        X = df[['deadline_urgency', 'project_priority', 'complexity_score', 
                'stakeholder_impact', 'business_value', 'num_dependencies']]
        y = df['priority_label']  # 1-5 scale
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        self.model.fit(X_train_scaled, y_train)
        self.is_trained = True
        
        # Evaluate
        predictions = self.model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, predictions)
        print(f"Priority Classification Accuracy: {accuracy:.2f}")
        
        return accuracy
    
    def predict_priority(self, task_features):
        """Predict task priority (1-5 scale)"""
        if not self.is_trained:
            return 3  # Default medium priority
        
        features_scaled = self.scaler.transform(task_features)
        prediction = self.model.predict(features_scaled)[0]
        return int(prediction)
