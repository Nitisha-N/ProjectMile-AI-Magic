"""Sample example tools."""
