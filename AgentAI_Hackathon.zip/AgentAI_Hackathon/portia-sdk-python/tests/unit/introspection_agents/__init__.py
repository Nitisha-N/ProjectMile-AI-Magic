"""Tests for introspection agents."""
