# One-command setup for AgentHack judges/reviewers
git clone [your-repo]
cd project-management-ai
pip install -r requirements.txt
python src/ml/generate_sample_data.py
python -c "from src.ml.models import *; import pandas as pd; df = pd.read_csv('./data/sample_training_data.csv'); d = DeadlinePredictionModel(); d.train(df.to_dict('records')); d.save_model('./models/deadline_model.pkl'); p = TaskPriorityModel(); p.train(df.to_dict('records')); p.save_model('./models/priority_model.pkl')"
python -m src.api.main &
sleep 5
python demo_script.py
``` AI agent
project_agent = ProjectManagerAgent()

@app.get("/")
async def root():
    return {"message": "Project Management AI is running!"}

@app.post("/projects/")
async def create_project(project_data: dict, db: Session = Depends(get_db_session)):
    # Use AI agent to create comprehensive project plan
    ai_plan = project_agent.create_project_plan(project_data)
    
    # Save to database
    project = Project(
        name=project_data["name"],
        description=project_data.get("description", ""),
        deadline=project_data.get("deadline"),
        priority=project_data.get("priority", 1)
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    
    return {"project": project, "ai_plan": ai_plan}

@app.get("/projects/{project_id}/insights")
async def get_project_insights(project_id: int):
    insights = project_agent.generate_insights(project_id)
    return insights

@app.get("/projects/{project_id}/predictions")
async def get_completion_predictions(project_id: int):
    predictions = project_agent.predict_project_completion(project_id)
    return predictions

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
