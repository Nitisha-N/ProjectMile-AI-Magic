# ProjectPulse - AI Project Health Dashboard 🚀

**Built for AgentHack 2025 with Portia AI Integration**

An intelligent web dashboard that uses **Portia AI** to analyze GitHub repositories and provide project managers with AI-powered insights, completion tracking, and strategic recommendations.

## 🎯 AgentHack 2025 Features

- ✅ **Mandatory Portia Integration**: Uses Portia AI for intelligent project analysis
- 📊 **Visual Dashboard**: Real-time charts and metrics
- 🤖 **AI-Powered Insights**: Smart recommendations from Portia
- 📈 **Project Health Scoring**: 1-10 health assessment
- ⚡ **Real-time Analysis**: Live GitHub data integration
- 🎨 **Professional UI**: Clean, responsive design

## 🏆 AgentHack 2025 Alignment

**Judging Criteria Coverage:**
- **Potential Impact** ✅: Helps PMs make data-driven decisions instantly
- **Creativity & Originality** ✅: Novel use of Portia for project management
- **Learning & Growth** ✅: Demonstrates Portia AI capabilities
- **Implementation** ✅: Full-stack app with Portia integration
- **Aesthetics & UX** ✅: Professional dashboard interface

## 🚀 URGENT SETUP (10 Minutes) - Competition Ends Soon!

### Step 1: Install Dependencies
```bash
pip install -r requirements-portia.txt
```

### Step 2: Environment Setup
Create `.env` file:
```bash
PORTIA_API_KEY=prt-0PKbe3gy.xNJ44YJ3RqtriikqrIUzXRazgIcSHrVT
OPENAI_API_KEY=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
```

### Step 3: Project Structure
```
your-project/
├── portia-app.py          # Main Portia-powered backend
├── requirements-portia.txt # Dependencies with Portia
├── .env                   # API keys
└── templates/
    └── index.html         # Frontend dashboard
```

### Step 4: Run Application
```bash
python portia-app.py
```

Visit: `http://localhost:5000`

## 🤖 How Portia Integration Works

1. **Portia AI Agent**: Initializes with full tool registry
2. **Smart Analysis**: Uses Portia's tools for GitHub data analysis  
3. **AI Recommendations**: Portia generates intelligent PM guidance
4. **Structured Output**: JSON responses for web dashboard
5. **Real-time Insights**: Live analysis powered by Portia

## 📊 Dashboard Features

### Visual Components
- **Health Score Card**: 1-10 AI-powered rating
- **Completion Progress**: Real-time percentage tracking  
- **Interactive Charts**: Issues/PRs breakdown
- **AI Recommendations**: Portia-generated insights
- **Risk Alerts**: Automated bottleneck detection

### Portia-Powered Analysis
- Repository health assessment
- Development velocity calculation
- Team productivity insights
- Risk and bottleneck identification
- Strategic recommendations for PMs

## 🎯 Demo Repositories

Try these for impressive results:
- `microsoft/vscode` - Large enterprise project
- `facebook/react` - Popular open source
- `vercel/next.js` - Active development
- `nodejs/node` - Long-term project

## 🏃‍♂️ RAPID DEPLOYMENT FOR SUBMISSION

### Option 1: Local Demo (Fastest)
```bash
python portia-app.py
# Demo on localhost:5000
```

### Option 2: Cloud Deploy (10 min)
```bash
# Deploy to Railway/Heroku for live URL
git init
git add .
git commit -m "AgentHack 2025 submission"
# Push to deployment platform
```

## 🎬 Presentation Script for Judges

1. **Open Dashboard**: Show clean, professional interface
2. **Enter Repository**: Type `microsoft/vscode`
3. **Show Portia Working**: Point out "Portia AI analyzing..." message
4. **Review Results**: Highlight health score, completion rate
5. **Showcase AI**: Read Portia's recommendations aloud
6. **Explain Impact**: "Saves PMs hours of manual analysis"

## 🏆 Key Differentiators

- **Portia Integration**: Mandatory requirement ✅
- **AI-First Approach**: Not just metrics, but insights
- **PM-Focused**: Designed for project management use case
- **Real-time**: Live GitHub API integration
- **Professional**: Production-ready dashboard

## ⚡ Last-Minute Optimizations

1. **Demo Data**: Pre-load with impressive repository
2. **Error Handling**: Graceful fallbacks if Portia times out
3. **Visual Polish**: Ensure charts render properly
4. **Loading States**: Show Portia is working
5. **Mobile Ready**: Test on phone/tablet

## 🎉 AgentHack Submission Checklist

- ✅ Portia integration implemented and working
- ✅ Web dashboard functional and responsive  
- ✅ AI-powered recommendations display
- ✅ GitHub API integration working
- ✅ Professional UI with charts/visualizations
- ✅ README with setup instructions
- ✅ Demo video/screenshots ready
- ✅ Submission form completed

## 🚨 SUBMISSION DEADLINE

**August 24, 10:00 PM IST** - You have ~25 hours!

## 🏅 Good luck at AgentHack 2025!

This project demonstrates:
- Advanced Portia AI integration
- Real-world problem solving  
- Full-stack development skills
- AI/ML application design
- Professional product delivery

**Built with ❤️ for AgentHack 2025**