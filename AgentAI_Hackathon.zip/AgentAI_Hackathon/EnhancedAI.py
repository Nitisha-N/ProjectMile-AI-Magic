from portia import Agent, Task, Plan, Clarification
import json
from datetime import datetime, timedelta
import os
from ..ml.models import DeadlinePredictionModel, TaskPriorityModel
from ..data.database import get_db_session
from ..data.schemas import Project, Task as TaskModel, MLTrainingData
from ..tools.project_tools import ProjectAnalysisTools, NotificationTools, IntegrationTools

class ProjectManagerAgent:
    def __init__(self):
        # Initialize the main agent with enhanced system prompt
        self.agent = Agent(
            name="ProjectManagerAgent",
            system_prompt="""You are an advanced AI project management assistant with machine learning capabilities.
            
            Your core competencies include:
            - Creating comprehensive project plans with realistic timelines
            - Analyzing project risks and bottlenecks using ML predictions
            - Integrating with external tools (Slack, Gmail, GitHub) for seamless workflow
            - Providing data-driven insights for project optimization
            - Managing stakeholder communications and updates
            - Learning from project outcomes to improve future predictions
            
            You should:
            1. Always ask for clarification when project requirements are ambiguous
            2. Use ML models to provide realistic estimates and priorities
            3. Consider team capacity, dependencies, and external factors
            4. Proactively identify risks and suggest mitigation strategies
            5. Maintain transparency in your decision-making process
            
            Be professional, precise, and always focus on actionable outcomes.""",
            model=os.getenv("OPENAI_MODEL", "gpt-4"),
            tools=[
                ProjectAnalysisTools(),
                NotificationTools(), 
                IntegrationTools()
            ]
        )
        
        # Initialize specialized sub-agents
        self.planning_agent = Agent(
            name="ProjectPlanningSpecialist",
            system_prompt="""You specialize in breaking down complex projects into manageable tasks.
            Focus on creating realistic timelines, identifying dependencies, and resource allocation.""",
            model=os.getenv("OPENAI_MODEL", "gpt-4")
        )
        
        self.risk_agent = Agent(
            name="RiskAnalysisSpecialist", 
            system_prompt="""You specialize in identifying project risks, bottlenecks, and potential issues.
            Use historical data and ML predictions to provide proactive risk management.""",
            model=os.getenv("OPENAI_MODEL", "gpt-4")
        )
        
        self.deadline_model = DeadlinePredictionModel()
        self.priority_model = TaskPriorityModel()
        
        # Load pre-trained models if they exist
        try:
            self.deadline_model.load_model("./models/deadline_model.pkl")
            self.priority_model.load_model("./models/priority_model.pkl")
        except:
            print("No pre-trained models found. Will train on first use.")
    
    def create_project_plan(self, project_data):
        """Create a comprehensive project plan using multi-agent collaboration"""
        
        # Step 1: Clarify ambiguous requirements
        clarifications_needed = self._check_for_clarifications(project_data)
        
        if clarifications_needed:
            clarification = Clarification(
                message="I need some additional information to create an optimal project plan:",
                options=clarifications_needed
            )
            return {"clarification_required": clarification}
        
        # Step 2: Multi-agent planning approach
        plan = Plan([
            Task(
                name="analyze_project_scope",
                description=f"Analyze the scope and requirements for: {project_data.get('name', 'Unnamed Project')}",
                agent=self.planning_agent,
                prompt=f"""
                Project Details:
                - Name: {project_data.get('name', '')}
                - Description: {project_data.get('description', '')}
                - Deadline: {project_data.get('deadline', '')}
                - Team Size: {project_data.get('team_size', 'Unknown')}
                - Budget: {project_data.get('budget', 'Not specified')}
                - Priority: {project_data.get('priority', 3)}/5
                
                Create a detailed project scope analysis including:
                1. Main deliverables and milestones
                2. Required skillsets and resources
                3. Initial timeline estimates
                4. Potential complexity factors
                """,
                tools=["project_analyzer", "resource_estimator"]
            ),
            Task(
                name="break_down_work_structure",
                description="Create detailed work breakdown structure with tasks",
                agent=self.planning_agent,
                depends_on=["analyze_project_scope"],
                tools=["task_generator", "dependency_mapper"]
            ),
            Task(
                name="apply_ml_predictions",
                description="Apply machine learning models for deadline prediction and task prioritization",
                prompt="Use the ML models to predict realistic completion times and optimize task priorities based on historical data",
                depends_on=["break_down_work_structure"]
            ),
            Task(
                name="risk_assessment",
                description="Identify potential risks and bottlenecks in the project plan",
                agent=self.risk_agent,
                depends_on=["apply_ml_predictions"],
                tools=["risk_analyzer", "bottleneck_detector"]
            ),
            Task(
                name="setup_integrations",
                description="Set up necessary tool integrations (Slack, GitHub, etc.) for project tracking",
                depends_on=["risk_assessment"],
                tools=["slack_integration", "github_integration", "calendar_sync"]
            )
        ])
        
        result = self.agent.run(plan)
        
        # Post-process with ML enhancements
        enhanced_result = self._enhance_with_ml_predictions(result, project_data)
        
        return enhanced_result
    
    def _check_for_clarifications(self, project_data):
        """Check if project data needs clarification"""
        clarifications = []
        
        if not project_data.get('description') or len(project_data.get('description', '')) < 20:
            clarifications.append({
                "question": "Can you provide more details about what this project involves?",
                "field": "description",
                "type": "text"
            })
        
        if not project_data.get('deadline'):
            clarifications.append({
                "question": "What's the target completion date for this project?",
                "field": "deadline", 
                "type": "date"
            })
        
        if not project_data.get('team_size'):
            clarifications.append({
                "question": "How many team members will be working on this project?",
                "field": "team_size",
                "type": "number"
            })
        
        if not project_data.get('budget'):
            clarifications.append({
                "question": "What's the approximate budget for this project?",
                "field": "budget",
                "type": "text",
                "optional": True
            })
        
        return clarifications if len(clarifications) > 0 else None
    
    def _enhance_with_ml_predictions(self, plan_result, project_data):
        """Enhance the plan with ML predictions"""
        # This would integrate the ML models with the plan results
        # Apply deadline predictions and priority optimizations
        enhanced_result = plan_result.copy()
        enhanced_result["ml_enhancements"] = {
            "predicted_completion_date": self._predict_overall_timeline(plan_result),
            "risk_score": self._calculate_risk_score(plan_result),
            "recommended_adjustments": self._get_ml_recommendations(plan_result)
        }
        return enhanced_result
    
    def optimize_task_priorities(self, project_id):
        """Optimize task priorities using ML"""
        with get_db_session() as session:
            tasks = session.query(TaskModel).filter(TaskModel.project_id == project_id).all()
            
            optimized_tasks = []
            for task in tasks:
                # Prepare features for ML model
                task_data = {
                    'days_until_deadline': (task.deadline - datetime.utcnow()).days if task.deadline else 30,
                    'project_priority': 3,  # Default, should be fetched from project
                    'complexity_score': task.complexity_score or 5,
                    'stakeholder_impact': 3,  # This would come from user input
                    'business_value': 3,     # This would come from user input
                    'dependencies': task.dependencies or '[]'
                }
                
                features = self.priority_model.prepare_features(task_data)
                predicted_priority = self.priority_model.predict_priority(features)
                
                task.priority = predicted_priority
                optimized_tasks.append({
                    'id': task.id,
                    'title': task.title,
                    'old_priority': task.priority,
                    'new_priority': predicted_priority
                })
            
            session.commit()
            return optimized_tasks
    
    def predict_project_completion(self, project_id):
        """Predict overall project completion time"""
        with get_db_session() as session:
            tasks = session.query(TaskModel).filter(
                TaskModel.project_id == project_id,
                TaskModel.status != 'completed'
            ).all()
            
            total_predicted_days = 0
            task_predictions = []
            
            for task in tasks:
                task_data = {
                    'estimated_hours': task.estimated_hours or 8,
                    'complexity_score': task.complexity_score or 5,
                    'project_priority': 3,  # Should be fetched from project
                    'assigned_experience': 3,  # Should be user input
                    'current_workload': 5,  # Should be calculated
                    'dependencies': task.dependencies or '[]'
                }
                
                features = self.deadline_model.prepare_features(task_data)
                predicted_days = self.deadline_model.predict_completion_time(features)
                
                total_predicted_days += predicted_days
                task_predictions.append({
                    'task_id': task.id,
                    'task_title': task.title,
                    'predicted_days': predicted_days
                })
            
            return {
                'total_predicted_days': total_predicted_days,
                'estimated_completion_date': datetime.utcnow() + timedelta(days=total_predicted_days),
                'task_predictions': task_predictions
            }
    
    def smart_project_monitoring(self, project_id):
        """Continuous monitoring with proactive notifications"""
        
        plan = Plan([
            Task(
                name="collect_project_metrics",
                description="Gather current project status, team velocity, and progress metrics",
                tools=["metrics_collector", "velocity_tracker"]
            ),
            Task(
                name="detect_anomalies",
                description="Use ML to detect unusual patterns or potential issues",
                depends_on=["collect_project_metrics"],
                tools=["anomaly_detector"]
            ),
            Task(
                name="generate_alerts",
                description="Create targeted alerts for stakeholders based on findings",
                depends_on=["detect_anomalies"],
                tools=["alert_generator", "notification_dispatcher"]
            ),
            Task(
                name="suggest_interventions",
                description="Recommend specific actions to address identified issues",
                depends_on=["generate_alerts"]
            )
        ])
        
        return self.agent.run(plan)
    
    def adaptive_resource_allocation(self, project_id, available_resources):
        """Dynamically optimize resource allocation using ML"""
        
        with get_db_session() as session:
            project = session.query(Project).filter(Project.id == project_id).first()
            tasks = session.query(TaskModel).filter(
                TaskModel.project_id == project_id,
                TaskModel.status.in_(['pending', 'in_progress'])
            ).all()
            
            plan = Plan([
                Task(
                    name="analyze_current_allocation",
                    description="Analyze current resource allocation efficiency",
                    prompt=f"""
                    Current project: {project.name}
                    Available resources: {available_resources}
                    Active tasks: {len(tasks)}
                    
                    Analyze the current resource allocation and identify optimization opportunities.
                    """
                ),
                Task(
                    name="predict_optimal_allocation",
                    description="Use ML models to predict optimal resource distribution",
                    depends_on=["analyze_current_allocation"],
                    tools=["resource_optimizer", "capacity_predictor"]
                ),
                Task(
                    name="create_reallocation_plan",
                    description="Create a detailed plan for resource reallocation",
                    depends_on=["predict_optimal_allocation"]
                ),
                Task(
                    name="notify_stakeholders",
                    description="Notify relevant stakeholders about recommended changes",
                    depends_on=["create_reallocation_plan"],
                    tools=["slack_notifier", "email_sender"]
                )
            ])
            
            return self.agent.run(plan)
    
    def handle_project_crisis(self, project_id, crisis_description):
        """Emergency response system for project crises"""
        
        # Use clarification to understand the crisis better
        clarification = Clarification(
            message="I need to understand the crisis better to provide the most effective response.",
            options=[
                {
                    "question": "What is the severity of this crisis?",
                    "field": "severity",
                    "type": "select",
                    "options": ["Low", "Medium", "High", "Critical"]
                },
                {
                    "question": "Are there any immediate deadlines at risk?",
                    "field": "deadlines_at_risk", 
                    "type": "boolean"
                },
                {
                    "question": "What resources are currently unavailable?",
                    "field": "unavailable_resources",
                    "type": "text"
                }
            ]
        )
        
        crisis_response_plan = Plan([
            Task(
                name="assess_impact",
                description=f"Assess the impact of: {crisis_description}",
                tools=["impact_analyzer", "timeline_calculator"]
            ),
            Task(
                name="identify_alternatives",
                description="Identify alternative solutions and workarounds",
                depends_on=["assess_impact"],
                tools=["solution_generator"]
            ),
            Task(
                name="prioritize_critical_path",
                description="Re-prioritize tasks to maintain critical project milestones",
                depends_on=["identify_alternatives"]
            ),
            Task(
                name="emergency_communications",
                description="Send immediate notifications to all stakeholders",
                depends_on=["prioritize_critical_path"],
                tools=["emergency_notifier", "stakeholder_updater"]
            ),
            Task(
                name="implement_recovery_plan",
                description="Execute the crisis recovery plan",
                depends_on=["emergency_communications"]
            )
        ])
        
        return {
            "clarification": clarification,
            "emergency_plan": self.agent.run(crisis_response_plan)
        }
    
    def learn_from_project_completion(self, project_id):
        """Post-project learning to improve future predictions"""
        
        with get_db_session() as session:
            project = session.query(Project).filter(Project.id == project_id).first()
            completed_tasks = session.query(TaskModel).filter(
                TaskModel.project_id == project_id,
                TaskModel.status == 'completed'
            ).all()
            
            # Extract learning data
            learning_data = []
            for task in completed_tasks:
                if task.actual_hours and task.estimated_hours:
                    learning_data.append({
                        'estimated_hours': task.estimated_hours,
                        'actual_hours': task.actual_hours,
                        'complexity_score': task.complexity_score or 5,
                        'dependencies_count': len(json.loads(task.dependencies or '[]')),
                        'completion_variance': (task.actual_hours - task.estimated_hours) / task.estimated_hours
                    })
            
            # Retrain models with new data
            if len(learning_data) >= 10:  # Minimum data threshold
                self._retrain_ml_models(learning_data)
            
            # Generate insights
            learning_plan = Plan([
                Task(
                    name="analyze_project_outcomes",
                    description=f"Analyze what we learned from project: {project.name}",
                    prompt=f"""
                    Project completed: {project.name}
                    Total tasks: {len(completed_tasks)}
                    Learning data points: {len(learning_data)}
                    
                    Analyze:
                    1. What went better than expected?
                    2. What took longer than predicted?
                    3. What patterns can we identify?
                    4. How can we improve future estimates?
                    """
                ),
                Task(
                    name="update_knowledge_base",
                    description="Update internal knowledge base with lessons learned",
                    depends_on=["analyze_project_outcomes"],
                    tools=["knowledge_updater"]
                ),
                Task(
                    name="share_insights",
                    description="Share insights with the team for collective learning",
                    depends_on=["update_knowledge_base"],
                    tools=["insight_sharer", "team_notifier"]
                )
            ])
            
            return self.agent.run(learning_plan)
