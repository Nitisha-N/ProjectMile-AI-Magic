# src/integrations/mcp_tools.py
from portia.tools.mcp import MCPTool

class ProjectMCPIntegrations:
    """MCP integrations for external project management tools"""
    
    def __init__(self):
        # Jira MCP integration
        self.jira_tool = MCPTool(
            server_config={
                "command": "jira-mcp-server",
                "args": ["--api-token", os.getenv("JIRA_API_TOKEN")]
            }
        )
        
        # Notion MCP integration  
        self.notion_tool = MCPTool(
            server_config={
                "command": "notion-mcp-server", 
                "args": ["--token", os.getenv("NOTION_TOKEN")]
            }
        )
        
        # Asana MCP integration
        self.asana_tool = MCPTool(
            server_config={
                "command": "asana-mcp-server",
                "args": ["--access-token", os.getenv("ASANA_TOKEN")]
            }
        )
    
    def sync_with_jira(self, project_data):
        """Sync project data with Jira using MCP"""
        return self.jira_tool.call("create_project", project_data)
    
    def update_notion_docs(self, documentation_data):
        """Update project documentation in Notion"""
        return self.notion_tool.call("update_page", documentation_data)
    
    def sync_asana_tasks(self, tasks_data):
        """Sync tasks with Asana workspace"""
        return self.asana_tool.call("create_tasks", tasks_data)
