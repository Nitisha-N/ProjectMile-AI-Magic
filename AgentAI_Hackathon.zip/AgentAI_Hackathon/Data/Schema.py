from sqlalchemy import Column, Integer, String, DateTime, Float, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Project(Base):
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    start_date = Column(DateTime, default=datetime.utcnow)
    deadline = Column(DateTime)
    status = Column(String(50), default="active")
    priority = Column(Integer, default=1)  # 1-5 scale
    completion_percentage = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

class Task(Base):
    __tablename__ = "tasks"
    
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    assigned_to = Column(String(100))
    estimated_hours = Column(Float)
    actual_hours = Column(Float)
    complexity_score = Column(Float)  # 1-10 scale
    deadline = Column(DateTime)
    status = Column(String(50), default="pending")
    priority = Column(Integer, default=1)
    dependencies = Column(Text)  # JSON string of task IDs
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

class MLTrainingData(Base):
    __tablename__ = "ml_training_data"
    
    id = Column(Integer, primary_key=True)
    task_id = Column(Integer)
    features = Column(Text)  # JSON string
    target_completion_time = Column(Float)
    target_priority = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
