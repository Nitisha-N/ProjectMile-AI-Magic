# ProjectPulse Backend - Fast API Server for AgentHack 2025
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import requests
import os
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)

# Configuration - Update these
GITHUB_TOKEN = os.getenv('GITHUB_TOKEN', 'your_github_token_here')
PORTIA_API_KEY = os.getenv('PORTIA_API_KEY', 'your_portia_key_here')

class ProjectAnalyzer:
    def __init__(self, repo_name):
        self.repo = repo_name
        self.headers = {'Authorization': f'token {GITHUB_TOKEN}'}
        
    def get_project_data(self):
        """Fetch and analyze project data from GitHub API"""
        base_url = f"https://api.github.com/repos/{self.repo}"
        
        try:
            # Get repository info
            repo_response = requests.get(base_url, headers=self.headers)
            repo_data = repo_response.json()
            
            # Get issues
            issues_response = requests.get(f"{base_url}/issues?state=all&per_page=100", headers=self.headers)
            issues_data = issues_response.json()
            
            # Get pull requests
            prs_response = requests.get(f"{base_url}/pulls?state=all&per_page=100", headers=self.headers)
            prs_data = prs_response.json()
            
            # Analyze data
            analysis = self.analyze_project_health(repo_data, issues_data, prs_data)
            return analysis
            
        except Exception as e:
            return {"error": f"Failed to fetch data: {str(e)}"}
    
    def analyze_project_health(self, repo, issues, prs):
        """Analyze project health metrics"""
        # Calculate basic metrics
        total_issues = len([i for i in issues if 'pull_request' not in i])
        closed_issues = len([i for i in issues if i['state'] == 'closed' and 'pull_request' not in i])
        open_issues = total_issues - closed_issues
        
        total_prs = len(prs)
        closed_prs = len([pr for pr in prs if pr['state'] == 'closed'])
        open_prs = total_prs - closed_prs
        
        # Calculate completion percentage
        if total_issues > 0:
            completion_rate = (closed_issues / total_issues) * 100
        else:
            completion_rate = 100
        
        # Project duration
        created_date = datetime.strptime(repo['created_at'], '%Y-%m-%dT%H:%M:%SZ')
        days_active = (datetime.now() - created_date).days
        
        # Risk assessment
        overdue_issues = len([i for i in issues if i['state'] == 'open' and 'pull_request' not in i])
        blocked_issues = len([i for i in issues if 'blocked' in i.get('title', '').lower() or 'blocked' in i.get('body', '').lower()])
        
        # Generate recommendations
        recommendations = self.generate_recommendations(completion_rate, open_issues, open_prs, blocked_issues)
        
        return {
            "repo_name": repo['name'],
            "completion_rate": round(completion_rate, 1),
            "days_active": days_active,
            "total_issues": total_issues,
            "open_issues": open_issues,
            "closed_issues": closed_issues,
            "total_prs": total_prs,
            "open_prs": open_prs,
            "closed_prs": closed_prs,
            "blocked_issues": blocked_issues,
            "health_score": self.calculate_health_score(completion_rate, open_issues, open_prs),
            "recommendations": recommendations,
            "status": self.get_project_status(completion_rate)
        }
    
    def calculate_health_score(self, completion_rate, open_issues, open_prs):
        """Calculate overall project health score (1-10)"""
        base_score = completion_rate / 10
        
        # Deduct points for open issues/PRs
        if open_issues > 20:
            base_score -= 2
        elif open_issues > 10:
            base_score -= 1
            
        if open_prs > 10:
            base_score -= 1
        
        return max(1, min(10, round(base_score, 1)))
    
    def get_project_status(self, completion_rate):
        """Get project status based on completion rate"""
        if completion_rate >= 90:
            return "Near Complete"
        elif completion_rate >= 70:
            return "On Track"
        elif completion_rate >= 50:
            return "Progressing"
        else:
            return "Early Stage"
    
    def generate_recommendations(self, completion_rate, open_issues, open_prs, blocked_issues):
        """Generate actionable recommendations for project managers"""
        recommendations = []
        
        if completion_rate < 50:
            recommendations.append("Focus on closing critical issues to improve project momentum")
        
        if open_issues > 20:
            recommendations.append("Consider triaging open issues - close outdated ones")
        
        if open_prs > 10:
            recommendations.append("Prioritize code reviews to reduce PR backlog")
        
        if blocked_issues > 0:
            recommendations.append(f"Unblock {blocked_issues} blocked issues immediately")
        
        if completion_rate > 80:
            recommendations.append("Project is near completion - focus on final testing and deployment")
        
        if not recommendations:
            recommendations.append("Project health is good - maintain current development velocity")
        
        return recommendations

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/analyze/<path:repo_name>')
def analyze_project(repo_name):
    """API endpoint to analyze a GitHub repository"""
    analyzer = ProjectAnalyzer(repo_name)
    results = analyzer.get_project_data()
    return jsonify(results)

@app.route('/api/health')
def health_check():
    return jsonify({"status": "healthy", "timestamp": datetime.now().isoformat()})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)