# src/agents/learning_agent.py
from portia import Agent, Plan, Task
from portia.learning import UserLedLearning

class LearningProjectAgent:
    """Agent that learns from successful project patterns"""
    
    def __init__(self):
        self.agent = Agent(
            name="LearningProjectAgent",
            system_prompt="You learn from successful project management patterns and apply them to new projects.",
            model="gpt-4"
        )
        
        # Initialize User-Led Learning
        self.ull = UserLedLearning(
            agent=self.agent,
            example_storage_path="./learning_examples/"
        )
    
    def learn_from_successful_project(self, project_data, success_metrics):
        """Store successful project patterns for future learning"""
        
        example_plan = Plan([
            Task(
                name="analyze_success_factors",
                description=f"Identify what made project '{project_data['name']}' successful",
                prompt=f"""
                Project: {project_data['name']}
                Success metrics: {success_metrics}
                Timeline: {project_data.get('timeline_performance', 'N/A')}
                Team satisfaction: {project_data.get('team_satisfaction', 'N/A')}
                
                Extract key success patterns and best practices.
                """
            )
        ])
        
        # Store as learning example
        self.ull.add_example(
            task_description="successful project management pattern",
            example_plan=example_plan,
            context=project_data
        )
    
    def apply_learned_patterns(self, new_project_data):
        """Apply learned patterns to new project"""
        
        # ULL will automatically suggest similar successful patterns
        return self.ull.generate_plan(
            task_description=f"Create project plan similar to successful patterns for: {new_project_data['name']}",
            context=new_project_data
        )
