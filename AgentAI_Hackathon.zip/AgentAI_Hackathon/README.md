# ProjectPulse - AI Project Health Dashboard

🚀 **Built for AgentHack 2025** - An AI-powered web dashboard that analyzes GitHub repositories to provide project managers with actionable insights about project health, completion rates, and strategic recommendations.

## 🎯 Features

- **Real-time Project Analysis**: Fetches live data from GitHub repositories
- **Visual Health Dashboard**: Interactive charts showing issues, PRs, and completion rates
- **AI-Powered Recommendations**: Smart suggestions for project managers
- **Completion Tracking**: Calculates project completion percentage and timeline
- **Risk Assessment**: Identifies blocked issues and bottlenecks
- **Responsive Design**: Works on desktop and mobile devices

## 🏆 AgentHack 2025 Alignment

This project addresses key judging criteria:
- **Potential Impact**: Helps project managers make data-driven decisions
- **Creativity & Originality**: Combines GitHub API with AI-powered analysis
- **Implementation**: Fully functional full-stack web application
- **Aesthetics & UX**: Clean, intuitive dashboard interface
- **Learning & Growth**: Demonstrates rapid full-stack development

## 🚀 Quick Setup (5 Minutes)

### Prerequisites
- Python 3.8+
- GitHub Account (for API access)

### 1. Clone/Download Files
Download these files to your project directory:
- `backend-app.py`
- `index.html`
- `requirements.txt`

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up Environment Variables
Create a `.env` file with:
```bash
GITHUB_TOKEN=your_github_token_here
PORTIA_API_KEY=your_portia_key_here
```

**Get GitHub Token:**
1. Go to GitHub Settings > Developer settings > Personal access tokens
2. Generate new token with `repo` permissions
3. Copy and paste into `.env` file

### 4. Create Project Structure
```
your-project/
├── backend-app.py
├── requirements.txt
├── .env
└── templates/
    └── index.html
```

Move `index.html` into a `templates/` folder.

### 5. Run the Application
```bash
python backend-app.py
```

Visit `http://localhost:5000` to see your dashboard!

## 📊 How It Works

1. **Data Collection**: Uses GitHub API to fetch repository data
2. **Analysis Engine**: Calculates health metrics, completion rates
3. **AI Recommendations**: Generates actionable insights for PMs
4. **Visual Dashboard**: Displays results with interactive charts

## 🎨 Dashboard Features

- **Completion Rate**: Shows % of closed vs total issues/PRs
- **Health Score**: 1-10 rating based on project activity
- **Days Active**: Project timeline and duration
- **Issue/PR Charts**: Visual breakdown of work status
- **Smart Recommendations**: AI-generated action items
- **Detailed Metrics**: Comprehensive project statistics

## 🔧 Customization

You can easily customize:
- **Analysis Logic**: Modify `analyze_project_health()` method
- **Recommendations**: Update `generate_recommendations()` logic
- **UI Design**: Edit HTML/CSS in `index.html`
- **Add More Data Sources**: Extend to Jira, Slack, etc.

## 🏃‍♂️ Demo Repositories to Try

- `microsoft/vscode`
- `facebook/react`
- `vercel/next.js`
- `nodejs/node`
- `torvalds/linux`

## 🎯 Submission Ready Features

- ✅ Complete full-stack application
- ✅ AI-powered analysis and recommendations
- ✅ Visual dashboard with charts
- ✅ Real-time data from GitHub API
- ✅ Project manager focused insights
- ✅ Professional UI/UX design
- ✅ Easy deployment and setup

## 📱 Screenshots

The dashboard includes:
- Header with ProjectPulse branding
- Repository input field
- Loading animations
- Overview cards (completion %, health score)
- Interactive doughnut charts
- AI recommendations panel
- Detailed metrics table

## 🚀 Deployment Options

**For AgentHack Demo:**
1. **Local**: Run on your machine for presentation
2. **Cloud**: Deploy to Heroku/Railway/Vercel for live demo
3. **Video**: Record demo showing analysis of popular repos

## 🎉 AgentHack Presentation Tips

1. **Start with Problem**: "Project managers struggle to get quick insights"
2. **Show Solution**: Live demo analyzing a popular repo
3. **Highlight AI**: Emphasize the smart recommendations feature
4. **Show Impact**: "Saves PMs hours of manual analysis"
5. **Technical Excellence**: Mention real-time data, responsive design

## 🏆 Competitive Advantages

- **Speed**: Instant analysis vs manual reporting
- **Accuracy**: Real-time data vs outdated spreadsheets
- **Actionable**: Specific recommendations vs general metrics
- **Visual**: Charts and dashboards vs text reports
- **Scalable**: Works for any GitHub repository

Good luck with AgentHack 2025! 🚀