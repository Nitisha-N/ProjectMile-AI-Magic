import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import random

def generate_sample_data(n_samples=1000):
    """Generate sample project management data for ML training"""
    
    np.random.seed(42)
    random.seed(42)
    
    data = []
    
    for i in range(n_samples):
        # Task features
        estimated_hours = np.random.normal(16, 8)  # Average 2 days, std 1 day
        estimated_hours = max(1, estimated_hours)
        
        complexity_score = np.random.randint(1, 11)
        num_dependencies = np.random.poisson(2)
        project_priority = np.random.randint(1, 6)
        assigned_experience = np.random.randint(1, 6)
        current_workload = np.random.normal(6, 2)  # Hours per day
        current_workload = max(1, min(12, current_workload))
        
        # Calculate realistic completion time with some variance
        base_days = estimated_hours / current_workload
        complexity_multiplier = 1 + (complexity_score - 5) * 0.1
        dependency_delay = num_dependencies * 0.5
        experience_factor = 2.0 - (assigned_experience / 5.0)  # Less experience = more time
        
        actual_completion_days = base_days * complexity_multiplier * experience_factor + dependency_delay
        actual_completion_days += np.random.normal(0, actual_completion_days * 0.2)  # Add noise
        actual_completion_days = max(0.1, actual_completion_days)
        
        # Priority calculation
        urgency_factor = np.random.randint(1, 31)  # Days until deadline
        stakeholder_impact = np.random.randint(1, 6)
        business_value = np.random.randint(1, 6)
        
        priority_score = (
            (31 - urgency_factor) * 0.3 +  # More urgent = higher priority
            project_priority * 0.2 +
            stakeholder_impact * 0.2 +
            business_value * 0.2 +
            (11 - complexity_score) * 0.1  # Less complex = can be done sooner
        )
        
        # Convert to 1-5 scale
        priority_label = min(5, max(1, int(priority_score / 2) + 1))
        
        data.append({
            'estimated_hours': estimated_hours,
            'complexity_score': complexity_score,
            'num_dependencies': num_dependencies,
            'project_priority': project_priority,
            'assigned_experience': assigned_experience,
            'current_workload': current_workload,
            'actual_completion_days': actual_completion_days,
            'deadline_urgency': urgency_factor,
            'stakeholder_impact': stakeholder_impact,
            'business_value': business_value,
            'priority_label': priority_label
        })
    
    return pd.DataFrame(data)

if __name__ == "__main__":
    df = generate_sample_data()
    df.to_csv('./data/sample_training_data.csv', index=False)
    print(f"Generated {len(df)} sample records")
    print(df.head())
    print(df.describe())
