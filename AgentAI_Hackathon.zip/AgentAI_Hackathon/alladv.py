from fastapi import FastAPI, Depends, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Dict, Optional
from ..data.database import get_db_session, init_db
from ..agents.project_manager_agent import ProjectManagerAgent
from ..data.schemas import Project, Task
import uvicorn
import asyncio

app = FastAPI(
    title="AI-Powered Project Management System", 
    version="2.0.0",
    description="Advanced project management with Portia AI and ML predictions"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database and AI agent
init_db()
project_agent = ProjectManagerAgent()

# Pydantic models for API
class ProjectCreate(BaseModel):
    name: str
    description: str
    deadline: Optional[str] = None
    team_size: Optional[int] = 3
    priority: Optional[int] = 3
    budget: Optional[str] = None

class CrisisReport(BaseModel):
    description: str
    severity: Optional[str] = "medium"
    affected_resources: Optional[List[str]] = []

class ResourceAllocation(BaseModel):
    available_resources: Dict
    optimization_goals: Optional[List[str]] = ["efficiency", "skill_match"]

@app.get("/")
async def root():
    return {
        "message": "AI-Powered Project Management System", 
        "version": "2.0.0",
        "features": [
            "ML-powered predictions",
            "Multi-agent collaboration", 
            "Smart resource allocation",
            "Crisis management",
            "Real-time monitoring",
            "External integrations"
        ]
    }

@app.post("/projects/", tags=["Projects"])
async def create_project_with_ai(
    project_data: ProjectCreate, 
    db: Session = Depends(get_db_session)
):
    """Create a comprehensive project plan using AI agents and ML"""
    
    # Use AI agent to create comprehensive project plan
    ai_result = project_agent.create_project_plan(project_data.dict())
    
    # Check if clarification is needed
    if "clarification_required" in ai_result:
        return {
            "status": "clarification_needed",
            "clarification": ai_result["clarification_required"],
            "message": "Additional information needed to create optimal project plan"
        }
    
    # Save to database
    project = Project(
        name=project_data.name,
        description=project_data.description,
        deadline=project_data.deadline,
        priority=project_data.priority or 3
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    
    return {
        "project": {
            "id": project.id,
            "name": project.name,
            "created_at": project.created_at
        },
        "ai_analysis": ai_result,
        "status": "created",
        "message": "Project created with AI-powered planning"
    }

@app.get("/projects/{project_id}/insights", tags=["AI Insights"])
async def get_comprehensive_insights(project_id: int):
    """Get AI-powered insights with ML predictions"""
    
    try:
        # Multi-agent insight generation
        insights = project_agent.generate_insights(project_id)
        predictions = project_agent.predict_project_completion(project_id)
        optimizations = project_agent.optimize_task_priorities(project_id)
        
        return {
            "project_id": project_id,
            "ai_insights": insights,
            "ml_predictions": predictions,
            "priority_optimizations": optimizations,
            "generated_at": datetime.now().isoformat(),
            "confidence_score": 0.85  # Would be calculated based on data quality
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating insights: {str(e)}")

@app.post("/projects/{project_id}/monitor", tags=["Monitoring"])
async def start_smart_monitoring(
    project_id: int, 
    background_tasks: BackgroundTasks
):
    """Start continuous AI monitoring for the project"""
    
    def monitor_project():
        """Background task for continuous monitoring"""
        try:
            monitoring_result = project_agent.smart_project_monitoring(project_id)
            # In production, this would store results and trigger notifications
            print(f"Monitoring result for project {project_id}: {monitoring_result}")
        except Exception as e:
            print(f"Monitoring error for project {project_id}: {str(e)}")
    
    background_tasks.add_task(monitor_project)
    
    return {
        "project_id": project_id,
        "monitoring_status": "started",
        "message": "Continuous AI monitoring activated",
        "features": [
            "Anomaly detection",
            "Risk prediction",
            "Automated alerts",
            "Performance tracking"
        ]
    }

@app.post("/projects/{project_id}/optimize-resources", tags=["Resource Management"])
async def optimize_resource_allocation(
    project_id: int,
    resource_data: ResourceAllocation
):
    """Optimize resource allocation using ML algorithms"""
    
    try:
        optimization_result = project_agent.adaptive_resource_allocation(
            project_id, 
            resource_data.available_resources
        )
        
        return {
            "project_id": project_id,
            "optimization_result": optimization_result,
            "status": "optimized",
            "message": "Resource allocation optimized using ML algorithms"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Optimization error: {str(e)}")

@app.post("/projects/{project_id}/crisis", tags=["Crisis Management"])
async def handle_project_crisis(
    project_id: int,
    crisis_data: CrisisReport
):
    """Emergency AI response system for project crises"""
    
    try:
        crisis_response = project_agent.handle_project_crisis(
            project_id,
            crisis_data.description
        )
        
        return {
            "project_id": project_id,
            "crisis_response": crisis_response,
            "status": "emergency_plan_activated",
            "message": "AI crisis management system activated"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Crisis handling error: {str(e)}")

@app.post("/projects/{project_id}/complete", tags=["Learning"])
async def complete_project_with_learning(project_id: int):
    """Complete project and extract learnings for future improvements"""
    
    try:
        learning_result = project_agent.learn_from_project_completion(project_id)
        
        # Update project status
        with get_db_session() as db:
            project = db.query(Project).filter(Project.id == project_id).first()
            if project:
                project.status = "completed"
                project.completion_percentage = 100.0
                db.commit()
        
        return {
            "project_id": project_id,
            "learning_insights": learning_result,
            "status": "completed",
            "message": "Project completed and learnings extracted for AI improvement"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Completion error: {str(e)}")

@app.get("/projects/{project_id}/predictions", tags=["ML Predictions"])
async def get_ml_predictions(project_id: int):
    """Get detailed ML predictions for project timeline and risks"""
    
    try:
        predictions = project_agent.predict_project_completion(project_id)
        
        return {
            "project_id": project_id,
            "predictions": predictions,
            "model_info": {
                "deadline_model_trained": project_agent.deadline_model.is_trained,
                "priority_model_trained": project_agent.priority_model.is_trained,
                "prediction_confidence": "high" if both models trained else "medium"
            },
            "generated_at": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@app.get("/analytics/team-performance", tags=["Analytics"])
async def get_team_analytics():
    """Get team performance analytics and insights"""
    
    # Mock team data for demo
    mock_team_data = [
        {"name": "Alice", "completed_tasks": 15, "hours_logged": 120, "story_points_completed": 45},
        {"name": "Bob", "completed_tasks": 12, "hours_logged": 96, "story_points_completed": 36},
        {"name": "Charlie", "completed_tasks": 18, "hours_logged": 144, "story_points_completed": 54}
    ]
    
    # Use analytics tools
    from ..tools.project_tools import AnalyticsTools
    analytics = AnalyticsTools()
    
    velocity_result = analytics.velocity_tracker(mock_team_data, time_period_days=30)
    
    return {
        "team_analytics": velocity_result.data,
        "insights": [
            "Team velocity is above average",
            "Alice is the top performer this month",
            "Consider redistributing workload for better balance"
        ],
        "recommendations": [
            "Maintain current sprint capacity",
            "Focus on knowledge sharing",
            "Consider pairing junior and senior developers"
        ]
    }

@app.get("/health", tags=["System"])
async def health_check():
    """System health check including AI models status"""
    
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "components": {
            "database": "connected",
            "ml_models": {
                "deadline_predictor": "loaded" if project_agent.deadline_model.is_trained else "training_needed",
                "priority_classifier": "loaded" if project_agent.priority_model.is_trained else "training_needed"
            },
            "ai_agents": {
                "project_manager": "active",
                "planning_specialist": "active", 
                "risk_analyst": "active"
            },
            "integrations": {
                "slack": "ready",
                "github": "ready",
                "calendar": "ready"
            }
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
